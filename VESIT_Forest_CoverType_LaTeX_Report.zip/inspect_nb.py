import json

with open('notebook_latest.ipynb', 'r', encoding='utf-8') as f:
    nb = json.load(f)

for idx in range(len(nb['cells'])):
    c = nb['cells'][idx]
    src = ''.join(c.get('source', []))
    for k in ['dataset size', 'hyperparameter', 'feature group', 'terrain', 'size_rows', 'parameter_rows', 'feature_rows']:
        if k in src.lower():
            print(f"=== CELL {idx} ({c.get('cell_type')}) ===")
            print(src)
            # also print outputs if text/dataframe
            for out in c.get('outputs', []):
                if 'data' in out and 'text/plain' in out['data']:
                    print('OUTPUT:', ''.join(out['data']['text/plain']))
                elif 'text' in out:
                    print('OUTPUT TEXT:', ''.join(out['text']))
            print("="*60)
            break
